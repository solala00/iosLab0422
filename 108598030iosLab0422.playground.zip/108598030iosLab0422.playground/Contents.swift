//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


print("a-1")
let numbers = [10, 8, 20, 7, 56, 3, 2, 1, 99]
var finished = numbers.sorted(by:{(a:Int, b:Int)->Bool in return a<b})
for i in finished{
    print("\(i)", terminator: " ")
}


print("\na-2")
let mynumbers2 = [10, 8, 20, 7, 56, 3, 2, 1, 99]
var myfinished2 = mynumbers2.sorted(by:{(a, b) in return a < b})
for i in myfinished2{
    print("\(i)", terminator: " ")
}

print("\na-3")
let mynumbers3 = [10, 8, 20, 7, 56, 3, 2, 1, 99]
var myfinished3 = mynumbers3.sorted(by:{$0 < $1})
for i in myfinished3{
    print("\(i)", terminator: " ")
}

print("\nb")
func sum(from: Int, to: Int, f: (Int) -> (Int)) -> Int {
    var sum = 0
    for i in from...to {
        sum += f(i)
    }
    return sum
}
//closure f 實作範例1:
sum(from: 1, to: 10) {
    a in a
} // This will get the sum of the first 10 numbers
//closure f 實作範例2:
sum(from: 1, to: 10) {
    $0
} // This will also get the sum of the first 10 numbers
//Implement your code below so that the sum will be the total of all
//circumference
//1. Here we have an array that stores the radius of each circle
//2. use the equation Circumference = 2 x π × radius
//3. to avoid the type conversion problem, we use π = 3 instead of 3.14
let radius = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
var bAnswer = sum(from: radius.startIndex, to:radius.endIndex) { //請於此實作
    $0*2*3
}
print(bAnswer)

